// Maz Radwan QAP4
// Date: November 21,2023

const motelCustomer = {
  name: "Peter Parker",
  birthDate: new Date("1980-01-01"),
  gender: "Male",
  roomNumber: 101,
  roomPreferences: ["King Size Bed", "Non-Smoking", "Sea View"],
  paymentMethod: "Credit Card",
  mailingAddress: {
    street: "55 Main St",
    city: "St. Johns",
    state: "NL",
    postal: "A2H2K8",
  },
  phoneNumber: "709-555-3377",
  checkInDate: new Date("2023-11-20"),
  checkOutDate: new Date("2023-11-25"),

  getAge() {
    const today = new Date();
    let age = today.getFullYear() - this.birthDate.getFullYear();
    const m = today.getMonth() - this.birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < this.birthDate.getDate())) {
      age--;
    }
    return age;
  },

  getStayDuration() {
    const duration =
      (this.checkOutDate - this.checkInDate) / (1000 * 60 * 60 * 24);
    return duration;
  },
};

document.addEventListener("DOMContentLoaded", (event) => {
  const customerStory = `
      <p>Peter walked into the motel and was greeted at the counter. The woman at the counter greeted him and asked his name. He replied, "${
        motelCustomer.name
      }". She asked, "Are the last four digits of your phone number ${motelCustomer.phoneNumber.slice(
    -4
  )}?" He replied, "Yes". She asked, "How many nights will you be staying?" and he answered, "${motelCustomer.getStayDuration()}". "Okay," she answered, "you are in room ${
    motelCustomer.roomNumber
  } a ${motelCustomer.roomPreferences.join(
    ", "
  )} as per your booking and paying by ${
    motelCustomer.paymentMethod
  }. Your checkout date is ${motelCustomer.checkOutDate.toDateString()}." She noticed, "Today is your birthday ${motelCustomer.name.substring(
    0,
    5
  )} ! Happy Birthday. How does it feel to be ${motelCustomer.getAge()} years old?" He replied, "Don't ask," and went to his room.</p>
  `;

  document.body.innerHTML += customerStory;
  console.log(customerStory);
});
